package model;

import java.util.Scanner;

import interfaces.IFruit;

public class Fruit implements IFruit{
	private int id;
	private String name;
	private double price;

	public Fruit() {
		this.id = 0;
		this.name = "";
		this.price = 0;
	}

	public Fruit(int id, String name, double price) {
		this.id = id;
		this.name = name;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Fruit [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	
	public void input() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Nhập ID: ");
		this.id = scanner.nextInt();
		scanner.nextLine();
		System.out.print("Nhập Name: ");
		this.name = scanner.nextLine();
		System.out.print("Nhập Price: ");
		this.price = scanner.nextDouble();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public double priceForSale() {
		// TODO Auto-generated method stub
		return 0;
	}

}
