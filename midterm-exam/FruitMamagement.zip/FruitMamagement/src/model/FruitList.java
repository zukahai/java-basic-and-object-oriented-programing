package model;

import java.util.ArrayList;

public class FruitList {
	private ArrayList<Fruit> fruits;

	public FruitList() {
		fruits = new ArrayList<>();
	}

	public FruitList(ArrayList<Fruit> fruits) {
		this.fruits = fruits;
	}
	
	public void add(Fruit fruit) {
		Fruit fruitSearch = this.search(fruit.getId());
		if (fruitSearch != null) {
			System.out.println("Thêm thất bại. ID đã tồn tại");
			return;
		}
		fruits.add(fruit);
		System.out.println("Thêm thành công");
	}
	
	public void displayAll() {
		if (fruits.size() == 0)
			System.out.println("Danh sách rỗng");
		else {
			System.out.println("Danh sách trái cây");
			for (Fruit fruit: fruits)
				System.out.println(fruit);
		}
	}
	
	public void displayAllPriceForSale() {
		double priceForSale = 20;
		ArrayList<Fruit> fruits = this.getAllPriceForSale(priceForSale);
		if (fruits.size() == 0)
			System.out.println("Không có trái cây nào có PriceForSale > " + priceForSale);
		else {
			System.out.println("Danh sách trái cây có PriceForSale > " + priceForSale + ":");
			for (Fruit fruit: fruits)
				System.out.println(fruit);
		}
	}
	
	public ArrayList<Fruit> getAllPriceForSale(double price) {
		ArrayList<Fruit> fruits = new ArrayList<>();
		for (Fruit fruit: this.fruits)
			if (fruit.priceForSale() > price)
				fruits.add(fruit);
		return fruits;
	}
	
	
	public Fruit search(int id) {
		for (Fruit fruit: fruits)
			if (fruit.getId() == id)
				return fruit;
		return null;
	}
	
	public int countFruit() {
		return fruits.size();
	}

	@Override
	public String toString() {
		return "FruitList [fruits=" + fruits + "]";
	}

	public ArrayList<Fruit> getFruits() {
		return fruits;
	}

	public void setFruits(ArrayList<Fruit> fruits) {
		this.fruits = fruits;
	}
	
	
}
