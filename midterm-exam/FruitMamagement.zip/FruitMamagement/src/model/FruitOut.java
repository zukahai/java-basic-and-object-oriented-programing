package model;

import java.util.Scanner;

public class FruitOut extends Fruit {
	private String orgin;
	private double extraOut;

	public FruitOut() {
		super();
		this.orgin = "";
		this.extraOut = 0;
	}

	public FruitOut(int id, String name, double price, String orgin, double extraOut) {
		super(id, name, price);
		this.orgin = orgin;
		this.extraOut = extraOut;
	}

	@Override
	public String toString() {
		return "FruitOut [id=" + super.getId() + ", name=" + super.getName() + ", price=" + super.getPrice()
				+ ", orgin=" + orgin + ", extraOut=" + extraOut + "]";
	}
	
	public void input() {
		super.input();
		Scanner scanner = new Scanner(System.in);
		System.out.print("Nhập Orgin: ");
		this.orgin = scanner.nextLine();
		System.out.print("Nhập ExtraOut: ");
		this.extraOut = scanner.nextDouble();
	}
	
	public double priceForSale() {
		return super.getPrice() + extraOut * 1.1;
	}

	public String getOrgin() {
		return orgin;
	}

	public void setOrgin(String orgin) {
		this.orgin = orgin;
	}

	public double getExtraOut() {
		return extraOut;
	}

	public void setExtraOut(double extraOut) {
		this.extraOut = extraOut;
	}

}
