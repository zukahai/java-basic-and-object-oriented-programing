package model;

import java.util.Scanner;

public class Menu {
	private FruitList fruitList;

	public Menu() {
		this.fruitList = new FruitList();
	}

	public Menu(FruitList fruitList) {
		this.fruitList = fruitList;
	}
	
	public int choice() {
		System.out.println("+-------------- Menu -----------+");
		System.out.println("| 1. Nhập Fruit                 |");
		System.out.println("| 2. Danh sách Fruit            |");
		System.out.println("| 3. Fruit có priceForSale > 20 |");
		System.out.println("| 4. Tổng số Fruit              |");
		System.out.println("| 5. Thoát                      |");
		System.out.println("+-------------------------------+");
		System.out.print("Nhập lựa chọn: ");
		
		Scanner scanner = new Scanner(System.in);
		return scanner.nextInt();
	}
	
	public int choiceAdd() {
		System.out.println("------ Add Fruit ------+");
		System.out.println("| 1. Nhập FruitIn      |");
		System.out.println("| 2. Nhập FruitOut     |");
		System.out.println("+----------------------+");
		System.out.print("Nhập lựa chọn: ");
		
		Scanner scanner = new Scanner(System.in);
		return scanner.nextInt();
	}
	
	public void run() {
		int c1, c2;
		Fruit fruit;
		do {
			c1 = choice();
			switch (c1) {
				case 1:
					c2 = choiceAdd();
					switch(c2) {
						case 1:
							fruit = new FruitIn();
							fruit.input();
							fruitList.add(fruit);
							break;
						case 2:
							fruit = new FruitOut();
							fruit.input();
							fruitList.add(fruit);
							break;
					}
					break;
				case 2:
					fruitList.displayAll();
					break;
				case 3:
					fruitList.displayAllPriceForSale();
					break;
				case 4:
					int count = fruitList.countFruit();
					System.out.println("Tổng số Fruit: " + count);
					break;
			}
		} while (c1 != 5);
		System.out.println("Kết thúc");
	}

	@Override
	public String toString() {
		return "Menu [fruitList=" + fruitList + "]";
	}

	public FruitList getFruitList() {
		return fruitList;
	}

	public void setFruitList(FruitList fruitList) {
		this.fruitList = fruitList;
	}
	
	
}
