package interfaces;

public interface IFruit {
	double priceForSale();
}
