package interfaces;

public interface GeometricObject {
	double getArea();
    double getPerimeter();
}
