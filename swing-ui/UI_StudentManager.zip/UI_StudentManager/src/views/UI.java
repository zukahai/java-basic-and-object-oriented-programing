package views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JRadioButton;

public class UI extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JPanel panel_1;
	private JLabel lblNewLabel;
	public JTextField masv;
	private JLabel lblNewLabel_1;
	public JTextField name;
	private JLabel lblNewLabel_2;
	public JTextField age;
	public JButton submit;
	private Vector<Object> vT;
	public JRadioButton rd1, rd2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UI frame = new UI();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 821, 385);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 4));
		panel.setBounds(330, 11, 473, 327);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(26, 24, 426, 280);
		panel.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		vT = new Vector<>();
		vT.add("Mã sinh viên");
		vT.add("Tên");
		vT.add("Tuổi");
		vT.add("Giới tính");
		
		
		Vector vD = new Vector();
		DefaultTableModel defaultTableModel = new DefaultTableModel(vD, vT);
		table.setModel(defaultTableModel);
		
		panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 4));
		panel_1.setBounds(10, 11, 311, 327);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		lblNewLabel = new JLabel("Mã sinh viên");
		lblNewLabel.setBounds(25, 49, 73, 14);
		panel_1.add(lblNewLabel);
		
		masv = new JTextField();
		masv.setBounds(123, 46, 155, 20);
		panel_1.add(masv);
		masv.setColumns(10);
		
		lblNewLabel_1 = new JLabel("Tên");
		lblNewLabel_1.setBounds(25, 93, 73, 14);
		panel_1.add(lblNewLabel_1);
		
		name = new JTextField();
		name.setColumns(10);
		name.setBounds(123, 90, 155, 20);
		panel_1.add(name);
		
		lblNewLabel_2 = new JLabel("Tuổi");
		lblNewLabel_2.setBounds(25, 140, 73, 14);
		panel_1.add(lblNewLabel_2);
		
		age = new JTextField();
		age.setColumns(10);
		age.setBounds(123, 137, 155, 20);
		panel_1.add(age);
		
		rd1 = new JRadioButton("Nam");
		rd1.setBounds(121, 189, 55, 23);
		panel_1.add(rd1);
		
		rd2 = new JRadioButton("Nữ");
		rd2.setBounds(184, 189, 109, 23);
		panel_1.add(rd2);
		
		ButtonGroup buttonGroup = new ButtonGroup();
		buttonGroup.add(rd1);
		buttonGroup.add(rd2);
		rd1.setSelected(true);
		
		JLabel lblNewLabel_2_1 = new JLabel("Giứo tính");
		lblNewLabel_2_1.setBounds(25, 193, 73, 14);
		panel_1.add(lblNewLabel_2_1);
		
		submit = new JButton("Thêm");
		submit.setBounds(111, 260, 89, 23);
		panel_1.add(submit);
		setVisible(true);
	}
	
	public void setVD(Vector vD) {
		DefaultTableModel defaultTableModel = new DefaultTableModel(vD, vT);
		table.setModel(defaultTableModel);
	}
}
