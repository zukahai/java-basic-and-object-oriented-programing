package interfaces;

import java.util.ArrayList;

import models.Student;

public interface IManager {
	void add(Student s);
	ArrayList<Student> findAll();
}
