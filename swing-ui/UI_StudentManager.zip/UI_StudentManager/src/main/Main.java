package main;

import controllers.StudentController;

public class Main {
	public static void main(String[] args) {
		StudentController s = new StudentController();
	}
}
