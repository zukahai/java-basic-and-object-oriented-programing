package controllers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import models.Student;
import models.StudentManager;
import views.UI;

public class StudentController {
	private UI ui;
	private StudentManager manager;
	public StudentController() {
		this.ui = new UI();
		this.manager = new StudentManager();
		this.solve();
	}
	public StudentController(UI ui, StudentManager manager) {
		this.ui = ui;
		this.manager = manager;
		this.solve();
	}
	
	public void solve() {
		ui.submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String masv = ui.masv.getText();
				String name = ui.name.getText();
				int age = Integer.parseInt(ui.age.getText());
				String gender = ui.rd1.isSelected() ? ui.rd1.getText() : ui.rd2.getText();
				Student student = new Student(masv, name, age, gender);
				
				manager.add(student);
				Vector<Object> vD = manager.toVector();
				ui.setVD(vD);
			}
		});
	}
	
	
}
