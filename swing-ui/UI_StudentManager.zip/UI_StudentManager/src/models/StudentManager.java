package models;

import java.util.ArrayList;
import java.util.Vector;

import interfaces.IManager;

public class StudentManager implements IManager {
	private ArrayList<Student> students;

	public StudentManager() {
		students = new ArrayList<>();
	}

	public StudentManager(ArrayList<Student> students) {
		this.students = students;
	}

	@Override
	public void add(Student s) {
		for (Student student: students)
			if (s.getMasv().equals(student.getMasv())) {
				System.out.println("Thêm thất bại");
				return;
			}
		students.add(s);
	}

	@Override
	public ArrayList<Student> findAll() {
		// TODO Auto-generated method stub
		return students;
	}
	
	public Vector toVector() {
		Vector<Object> ans = new Vector<>();
		for (Student student: students) 
			ans.add(student.toVector());
		return ans;
	}

}
