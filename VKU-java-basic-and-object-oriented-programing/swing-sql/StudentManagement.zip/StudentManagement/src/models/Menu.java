package models;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
	private StudentManager manager;

	public Menu() {
		this.manager = new StudentManager();
	}

	public Menu(StudentManager manager) {
		this.manager = manager;
	}
	
	private int choice() {
		System.out.println();
		System.out.println("+----------- Menu -----------+");
		System.out.println("| 1. Xem danh sách sinh viên |");
		System.out.println("| 2. Thêm sinh viên          |");
		System.out.println("| 3. Sửa thông tin sinh viên |");
		System.out.println("| 4. Xoá sinh viên           |");
		System.out.println("| 5. Tìm kiếm sinh viên      |");
		System.out.println("| 6. Thoát                   |");
		System.out.println("+----------------------------+");
		System.out.print("Nhập lựa chọn của bạn: ");
		Scanner sc = new Scanner(System.in);
		try {
			return sc.nextInt();
		} catch (Exception e) {
			return 0;
		}
	}
	
	private int choice(int subChoice) {
		if (subChoice == 5) {
			System.out.println("+------ Tìm kiếm ------+");
			System.out.println("| 1. Theo mã sinh viên |");
			System.out.println("| 2. Theo tên          |");
			System.out.println("| 3. Theo địa chỉ      |");
			System.out.println("+----------------------+");
		}
		System.out.print("Nhập lựa chọn của bạn: ");
		Scanner sc = new Scanner(System.in);
		try {
			return sc.nextInt();
		} catch (Exception e) {
			return 0;
		}
	}
	
	public void displayAll() {
		ArrayList<Student> students = manager.getAll();
		displayArrayList(students);
	}
	
	public void addStudent() {
		Student student = new Student();
		student.input();
		boolean success = manager.add(student);
		if (success) {
			System.out.println("Thêm thành công");
		} else {
			System.out.println("Thêm thất bại");
		}
	}
	
	public void editStudent() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhập mã sinh viên của sinh viên cần sửa: ");
		String masv = sc.nextLine();
		Student student = manager.findByMasv(masv);
		if (student == null) {
			System.out.println("Mã sinh viên không đúng!");
			return;
		}
		
		Student newStudent = new Student();
		newStudent.input();
		
		boolean success = manager.edit(masv, newStudent);
		if (success)
			System.out.println("Sửa thành công");
		else
			System.out.println("Sửa thất bại");
	}
	
	public void deleteStudent() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhập mã sinh viên của sinh viên cần xoá: ");
		String masv = sc.nextLine();
		Student student = manager.findByMasv(masv);
		if (student == null) {
			System.out.println("Mã sinh viên không đúng!");
			return;
		}
		
		boolean success = manager.delete(masv);
		
		if (success)
			System.out.println("Xoá thành công");
		else
			System.out.println("Xoá thất bại");
		
	}
	
	public void searchStudent(int choice) {
		Scanner sc = new Scanner(System.in);
		boolean success;
		if (choice == 1) {
			System.out.print("Nhập mã sinh viên của sinh viên cần tìm kiếm: ");
			String masv = sc.nextLine();
			Student student = manager.findByMasv(masv);
			if (student != null) {
				System.out.println("Tìm kiếm thành công");
				System.out.println(student);
			} else {
				System.out.println("Không tìm thấy");
			}
		}
		
		if (choice == 2) {
			System.out.print("Nhập tên của sinh viên cần tìm kiếm: ");
			String name = sc.nextLine();
			ArrayList<Student> students = manager.findByName(name);
			displayArrayList(students);
		}
		
		if (choice == 3) {
			System.out.print("Nhập địa chỉ của sinh viên cần tìm kiếm: ");
			String address = sc.nextLine();
			ArrayList<Student> students = manager.findByAddress(address);
			displayArrayList(students);
		}
	}
	
	public void displayArrayList(ArrayList<Student> students) {
		if (students.size() == 0) {
			System.out.println("Danh sách rỗng");
		} else {
			System.out.println("Danh sách sinh viên");
			for (Student student: students)
				System.out.println(student);
		}
	}
	
	public void run() {
		int c, c2;
		do {
			c = choice();
			switch (c) {
				case 1: 
					displayAll();
					break;
				case 2:
					addStudent();
					break;
				case 3:
					editStudent();
					break;
				case 4:
					deleteStudent();
					break;
				case 5:
					c2 = choice(c);
					searchStudent(c2);
					break;
			}
		} while(c != 6);
		System.out.println("Kết thúc");
	}
	
	
}
