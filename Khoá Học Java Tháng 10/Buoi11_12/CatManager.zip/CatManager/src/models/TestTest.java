package models;

public class TestTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cat meo1 = new Cat("Tom", 5, "Xám");
		System.out.println(meo1);
	}

}
