package Test;

import models.Cat;

public class Test {
	public static void main(String[] args) {
		Cat meo1 = new Cat("Tom", -30, "Xám");
		meo1.setMauLong("Xanh");
	}
}
