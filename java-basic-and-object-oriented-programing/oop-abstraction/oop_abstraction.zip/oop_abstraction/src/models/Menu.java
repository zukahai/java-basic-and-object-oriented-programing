package models;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
	private StudentManager manager;

	public Menu() {
		this.manager = new StudentManager();
	}

	public Menu(StudentManager manager) {
		this.manager = manager;
	}

	public int choice() {
		System.out.println("+---------- Menu ---------+");
		System.out.println("| 1. Hiển thị danh sách   |");
		System.out.println("| 2. Thêm sinh viên       |");
		System.out.println("| 3. Tìm kiếm sinh viên   |");
		System.out.println("| 4. Xoá sinh viên        |");
		System.out.println("| 5. Sắp xếp sinh viên    |");
		System.out.println("| 6. Chỉnh sửa sinh viên  |");
		System.out.println("| 7. Thoát chương trình   |");
		System.out.println("+-------------------------+");
		System.out.print("Nhập lựa chọn: ");
		Scanner scanner = new Scanner(System.in);
		int choice = scanner.nextInt();
		return choice;
	}

	public int choice(int subChoice) {
		switch (subChoice) {
			case 2:
				System.out.println("+----- Thêm sinh viên ----+");
				System.out.println("| 1. Thêm sinh viên IT    |");
				System.out.println("| 2. Thêm sinh viên BA    |");
				System.out.println("+-------------------------+");
				break;
			case 3:
				System.out.println("+--- Tìm kiếm sinh viên --+");
				System.out.println("| 1. Tìm kiếm theo MSSV   |");
				System.out.println("| 2. Tìm kiếm theo Age    |");
				System.out.println("+-------------------------+");
				break;
			case 5:
				System.out.println("+--- Sắp xếp sinh viên ---+");
				System.out.println("| 1. Theo tuổi            |");
				System.out.println("| 2. Theo điểm trung bình |");
				System.out.println("+-------------------------+");
				break;
		}

		System.out.print("Nhập lựa chọn: ");
		Scanner scanner = new Scanner(System.in);
		int choice = scanner.nextInt();
		return choice;
	}

	public void displayAllStudents() {
		manager.displayAllStudents();
	}

	public void addStudent(int choice) {
		Student student;
		if (choice == 1)
			student = new StudentIT();
		else
			student = new StudentBA();
		student.input();
		manager.addStudent(student);
	}
	
	public void findStudent(int choice) {
		Scanner scanner = new Scanner(System.in);
		if (choice == 1) {
			System.out.print("Nhập MSSV cần tìm kiếm: ");
			String masv = scanner.nextLine();
			Student student = manager.findStudent(masv);
			if (student == null) {
				System.out.println("Không có sinh viên nào có masv là " + masv);
			} else {
				System.out.println("Tìm kiếm thành công:");
				System.out.println(student);
			}
		} else {
			System.out.print("Nhập Age cần tìm kiếm: ");
			int age = scanner.nextInt();
			ArrayList<Student> studentByAge = manager.findStudent(age);
			if (studentByAge.size() == 0) {
				System.out.println("Không có sinh viên nào có Age là " + age);
			} else {
				System.out.println("Tìm kiếm thành công:");
				for (int i = 0; i < studentByAge.size(); i++) {
					Student student = studentByAge.get(i);
					System.out.println(student);
				}
			}
		}
	}
	
	public void removeStudent() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Nhập MSSV của sinh viên cần xoá: ");
		String masv = scanner.nextLine();
		manager.removeStudent(masv);
	}
	
	public void sortStudent(int choice) {
		if (choice == 1)
			manager.sortByAge();
		else
			manager.sortByScore();
	}
	
	public void editStudent() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Nhập Masv cần sửa: ");
		String masv = scanner.nextLine();
		Student student = manager.findStudent(masv);
		if (student == null) {
			System.out.println("Sinh viên không tồn tại.");
			return;
		}
		
		System.out.println("Nhập thông tin mới của sinh viên:");
		Student student2;
		if (student instanceof StudentIT) {
			student2 = new StudentIT();
		} else {
			student2 = new StudentBA();
		}
		student2.input();
		
		if (masv.equals(student2.getMasv())) {
			manager.editStudent(masv, student2);
			System.out.println("Cập nhập thành công");
		} else {
			Student student3 = manager.findStudent(student2.getMasv());
			if (student3 != null) {
				System.out.println("Mã sinh viên đã tồn tại");
			} else {
				manager.editStudent(masv, student2);
				System.out.println("Cập nhập thành công");
			}
		}
	}

	public void run() {
		int c1, c2;
		do {
			c1 = choice();
			switch (c1) {
				case 1:
					displayAllStudents();
					break;
				case 2:
					c2 = choice(c1);
					addStudent(c2);
					break;
				case 3:
					c2 = choice(c1);
					findStudent(c2);
					break;
				case 4:
					removeStudent();
					break;
				case 5:
					c2 = choice(c1);
					sortStudent(c2);
					break;
				case 6:
					editStudent();
					break;

			}
		} while (c1 != 7);
		System.out.println("Kết thúc");
	}

}
