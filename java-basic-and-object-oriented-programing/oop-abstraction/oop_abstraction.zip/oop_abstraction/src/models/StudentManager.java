package models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import interfaces.IManager;

public class StudentManager implements IManager {
	private ArrayList<Student> students;

	public StudentManager() {
		this.students = new ArrayList<>();
	}

	public StudentManager(ArrayList<Student> students) {
		this.students = students;
	}

	@Override
	public String toString() {
		return "StudentManager [students=" + students + "]";
	}

	public ArrayList<Student> getStudents() {
		return students;
	}

	public void setStudents(ArrayList<Student> students) {
		this.students = students;
	}

	@Override
	public void addStudent(Student student) {
		Student s = findStudent(student.getMasv());
		if (s != null) {
			System.out.println("Thêm thất bại, Masv đã tồn tại.");
			return;
		}
		students.add(student);

	}

	@Override
	public void editStudent(String masv, Student student) {
		for (int i = 0; i < students.size(); i++) {
			Student s = students.get(i);
			String masvStudent = s.getMasv();
			if (masvStudent.equals(masv)) {
				students.set(i, student);
			}
		}
	}

	@Override
	public void removeStudent(String masv) {
		Student student = findStudent(masv);
		if (student == null) {
			System.out.println("Xoá thất bại, không tồn tại sinh viên");
		} else {
			students.remove(student);
			System.out.println("Xoá thành công.");
		}
	}

	@Override
	public Student findStudent(String masv) {
		for (int i = 0; i < students.size(); i++) {
			Student student = students.get(i);
			String masvStudent = student.getMasv();
			if (masvStudent.equals(masv))
				return student;
		}
		return null;
	}

	@Override
	public void sortByAge() {
		Collections.sort(students, new Comparator<Student>() {
			@Override
			public int compare(Student o1, Student o2) {
				int age1 = o1.getAge();
				int age2 = o2.getAge();
				return age1 - age2;
			}
		});
		System.out.println("Sắp xếp thành công");
	}

	@Override
	public void sortByScore() {
		Collections.sort(students, new Comparator<Student>() {
			@Override
			public int compare(Student o1, Student o2) {
				float average1 = o1.calculateAverage();
				float average2 = o2.calculateAverage();
				return (average1 > average2) ? 1 : -1;
			}
		});
		System.out.println("Sắp xếp thành công");
	}

	@Override
	public ArrayList<Student> findStudent(int age) {
		ArrayList<Student> studentsByAge = new ArrayList<>();
		for (int i = 0; i < students.size(); i++) {
			Student student = students.get(i);
			int ageStudent = student.getAge();
			if (ageStudent == age)
				studentsByAge.add(student);
		}
		return studentsByAge;
	}

	@Override
	public void displayAllStudents() {
		if (students.size() == 0) {
			System.out.println("Danh sách rỗng");
			return;
		}

		System.out.println("Danh sách sinh viên");
		for (int i = 0; i < students.size(); i++) {
			Student student = students.get(i);
			System.out.println(student);
		}
	}

}
