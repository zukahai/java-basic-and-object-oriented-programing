package models;

import java.util.Scanner;

public class StudentBA extends Student {
	private float scorePM;
	private float scoreBA;

	public StudentBA() {
		super();
		this.scorePM = 0;
		this.scoreBA = 0;
	}

	public StudentBA(String masv, String name, int age, float scorePM, float scoreBA) {
		super(masv, name, age);
		this.scorePM = scorePM;
		this.scoreBA = scoreBA;
	}
	
	public void input() {
		super.input();
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter ScorePM: ");
		this.scorePM = sc.nextFloat();
		System.out.print("Enter ScoreBA: ");
		this.scoreBA = sc.nextFloat();
	}

	public float getScorePM() {
		return scorePM;
	}

	public void setScorePM(float scorePM) {
		this.scorePM = scorePM;
	}

	public float getScoreBA() {
		return scoreBA;
	}

	public void setScoreBA(float scoreBA) {
		this.scoreBA = scoreBA;
	}

	@Override
	public String toString() {
		return "StudentBA [masv=" + super.getMasv() + ", name=" + super.getName() + ", age=" + super.getAge() + 
				", scorePM=" + scorePM + ", scoreBA=" + scoreBA + "]";
	}

	@Override
	public float calculateAverage() {
		// TODO Auto-generated method stub
		return (scorePM + scoreBA) / 2;
	}

}
