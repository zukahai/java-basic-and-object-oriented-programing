package main;

import model.HardcoverBook;
import model.Menu;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Menu menu = new Menu();
		menu.run();
	}

}
