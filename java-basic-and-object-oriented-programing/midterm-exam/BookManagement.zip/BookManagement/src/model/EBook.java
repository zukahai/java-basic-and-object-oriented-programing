package model;

import java.util.Scanner;

public class EBook extends Book {
	private String format;
	private double fileSizeMB;

	public EBook() {
		super();
		this.format = "";
		this.fileSizeMB = 0;
	}

	public EBook(int bookID, String title, String author, long price, String format, double fileSizeMB) {
		super(bookID, title, author, price);
		this.format = format;
		this.fileSizeMB = fileSizeMB;
	}
	
	public void input() {
		super.input();
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhập Format: ");
		this.format = sc.nextLine();
		System.out.print("Nhập fileSizeMB: ");
		this.fileSizeMB = sc.nextDouble();
	}

	@Override
	public String toString() {
		return "EBook [bookID=" + super.getBookID() + ", title=" + super.getTitle() + ", author=" + super.getAuthor()
				+ ", price=" + super.getPrice() + ", format=" + format + ", fileSizeMB=" + fileSizeMB + "]";
	}
	
	public boolean isBigBook() {
		return this.fileSizeMB > 200;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public double getFileSizeMB() {
		return fileSizeMB;
	}

	public void setFileSizeMB(double fileSizeMB) {
		this.fileSizeMB = fileSizeMB;
	}

}
