package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class BookManager {
	private ArrayList<Book> books;

	public BookManager() {
		this.books = new ArrayList<>();
	}

	public BookManager(ArrayList<Book> books) {
		this.books = books;
	}
	
	public void addBook(Book b) {
		Book book = this.searchBook(b.getBookID());
		if (book != null) {
			System.out.println("Thêm thất bại, id sách đã tồn tại");
			return; // Thoát ngay phương thức
		}
		books.add(b);
		System.out.println("Thêm sách thành công.");
	}
	
	public ArrayList<Book> searchBook(String title) {
		ArrayList<Book> ans = new ArrayList<>();
		for (int i = 0; i < books.size(); i++) {
			Book b = books.get(i);
			String titleBook = b.getTitle();
			if (titleBook.equals(title))
				ans.add(b);
		}
		return ans;
	}
	
	public Book searchBook(int bookID) {
		for (int i = 0; i < books.size(); i++) {
			Book b = books.get(i);
			int id = b.getBookID();
			if (id == bookID)
				return b;
		}
		return null;
	}
	
	public void removeBook(int bookID) {
		for (int i = 0; i < books.size(); i++) {
			Book b = books.get(i);
			int id = b.getBookID();
			if (id == bookID)
				books.remove(i);
		}
	}
	
	public void displayBooks() {
		for (int i = 0; i < books.size(); i++) {
			Book b = books.get(i);
			System.out.println(b);
		}
	}
	
	public void sortByPrice() {
		Collections.sort(books, new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				// TODO Auto-generated method stub
				return (o1.getPrice() > o2.getPrice()) ? 1 : -1;
			}
		});
	}
	
	public void sortByType() {
		Collections.sort(books, new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				// TODO Auto-generated method stub
				if (o2 instanceof HardcoverBook && o1 instanceof EBook)
					return 1;
				return -1;
			}
			
		});
	}
	
	public long totalPrice() {
		long sum = 0;
		for (int i = 0; i < books.size(); i++) {
			Book b = books.get(i);
			long price = b.getPrice();
			sum += price;
		}
		return sum;
	}
	
	public double getTotalFileSize() {
		double sum = 0;
		for (int i = 0; i < books.size(); i++) {
			Book b = books.get(i);
			if (b instanceof EBook) {
				double fileSizeMB = ((EBook)b).getFileSizeMB();
				sum += fileSizeMB;
			}
		}
		return sum;
	}
	
	@Override
	public String toString() {
		return "BookManager [books=" + books + "]";
	}

	public ArrayList<Book> getBooks() {
		return books;
	}

	public void setBooks(ArrayList<Book> books) {
		this.books = books;
	}

}
