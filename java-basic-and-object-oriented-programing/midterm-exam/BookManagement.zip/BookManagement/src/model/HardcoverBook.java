package model;

import java.util.Scanner;

public class HardcoverBook extends Book {
	private String coverMaterial;
	private int numberOfPages;

	public HardcoverBook() {
		super();
		this.coverMaterial = "";
		this.numberOfPages = 0;
	}

	public HardcoverBook(int bookID, String title, String author, long price, String coverMaterial, int numberOfPages) {
		super(bookID, title, author, price);
		this.coverMaterial = coverMaterial;
		this.numberOfPages = numberOfPages;
	}

	public void input() {
		super.input();
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhập Cover Material: ");
		this.coverMaterial = sc.nextLine();
		System.out.print("Nhập Number Of Pages: ");
		this.numberOfPages = sc.nextInt();
	}

	@Override
	public String toString() {
		return "HardcoverBook [bookID=" + super.getBookID() + ", title=" + super.getTitle() + ", author="
				+ super.getAuthor() + ", price=" + super.getPrice() + ", coverMaterial=" + coverMaterial
				+ ", numberOfPages=" + numberOfPages + "]";
	}

	public String getCoverMaterial() {
		return coverMaterial;
	}

	public void setCoverMaterial(String coverMaterial) {
		this.coverMaterial = coverMaterial;
	}

	public int getNumberOfPages() {
		return numberOfPages;
	}

	public void setNumberOfPages(int numberOfPages) {
		this.numberOfPages = numberOfPages;
	}

}
