package model;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
	private BookManager bookManager;

	public Menu() {
		this.bookManager = new BookManager();
	}

	public Menu(BookManager bookManager) {
		this.bookManager = bookManager;
	}
	
	public int choice() {
		System.out.println("+------------- Menu -----------+");
		System.out.println("| 1. Xem danh sách sách        |");
		System.out.println("| 2. Thêm sách                 |");
		System.out.println("| 3. Tìm sách                  |");
		System.out.println("| 4. Xoá sách                  |");
		System.out.println("| 5. Sắp xếp                   |");
		System.out.println("| 6. Tính tổng giá sách        |");
		System.out.println("| 7. Tính tổng kích thước sách |");
		System.out.println("| 0. Thoát                     |");
		System.out.println("+------------------------------+");
		System.out.print("Nhập lựa chọn của bạn: ");
		Scanner sc = new Scanner(System.in);
		return sc.nextInt();
	}
	
	public int choice(int subMenu) {
		switch (subMenu) {
			case 2:
				System.out.println("+--------- Thêm sách ----------+");
				System.out.println("| 1. Thêm sách cứng            |");
				System.out.println("| 2. Thêm sách điện tử         |");
				System.out.println("+------------------------------+");
				break;
			case 3:
				System.out.println("+---------- Tìm sách ----------+");
				System.out.println("| 1. Tìm sách theo title       |");
				System.out.println("| 2. Tìm sách theo bookID      |");
				System.out.println("+------------------------------+");
				break;
			case 5:
				System.out.println("+----------- Sắp xếp ----------+");
				System.out.println("| 1. Sắp theo theo giá         |");
				System.out.println("| 2. Sắp theo theo loại        |");
				System.out.println("+------------------------------+");
				break;
		
		}
		System.out.print("Nhập lựa chọn của bạn: ");
		Scanner sc = new Scanner(System.in);
		return sc.nextInt();
	}
	
	public void display() {
		if (bookManager.getBooks().size() == 0) {
			System.out.println("\nDanh sách rỗng");
		} else {
			System.out.println("\nDanh sách:");
			this.bookManager.displayBooks();
		}
	}
	
	public void addBook(int choice) {
		Book book;
		if (choice == 1) {
			book = new HardcoverBook();
		} else {
			book = new EBook();
		}
		book.input();
		bookManager.addBook(book);
	}
	
	public void searchBook(int choice) {
		Scanner sc = new Scanner(System.in);
		if (choice == 1) {
			System.out.print("Nhập Title: ");
			String title = sc.nextLine();
			ArrayList<Book> books = bookManager.searchBook(title);
			if (books.size() == 0) {
				System.out.println("Không có sách nào có title là "+ title);
			} else {
				System.out.println("Danh sách sách có title là " + title);
				for (int i = 0; i < books.size(); i++)
					System.out.println(books.get(i));
			}
		} else {
			System.out.print("Nhập BookID: ");
			int bookID = sc.nextInt();
			Book book = bookManager.searchBook(bookID);
			if (book == null) {
				System.out.println("Không có sách nào có BookID là "+ bookID);
			} else {
				System.out.println("Sách có bookID là " + bookID + ":");
				System.out.println(book);
			}
		}
	}
	
	public void removeBook() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhập BookID: ");
		int bookID = sc.nextInt();
		bookManager.removeBook(bookID);
		System.out.println("Đã xoá sách có bookID là: " + bookID);
	}
	
	public void sortBook(int choice) {
		if (choice == 1)
			bookManager.sortByPrice();
		else
			bookManager.sortByType();
		System.out.println("Sắp xếp thành công");
	}
	
	public void totalPrice() {
		long total = bookManager.totalPrice();
		System.out.println("Tổng giá sách là: " + total);
	}
	
	public void getTotalFileSize() {
		double total = bookManager.getTotalFileSize();
		System.out.println("Tổng dung lượng lưu trữ là: " + total);
	}
	
	public void run() {
		int choice, subChoice;
		Scanner sc = new Scanner(System.in);
		do {
			choice = choice();
			switch (choice) {
				case 1:
					display();
					break;
				case 2:
					subChoice = choice(choice);
					addBook(subChoice);
					break;
				case 3:
					subChoice = choice(choice);
					searchBook(subChoice);
					break;
				case 4:
					removeBook();
					break;
				case 5:
					subChoice = choice(choice);
					sortBook(subChoice);
					break;
				case 6:
					totalPrice();
					break;
				case 7:
					getTotalFileSize();
					break;
			}
		} while (choice != 0);
		System.out.println("Kết thúc");
	}

	public BookManager getBookManager() {
		return bookManager;
	}

	public void setBookManager(BookManager bookManager) {
		this.bookManager = bookManager;
	}

}
