package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class StudentManager {
	private ArrayList<Student> students;

	public StudentManager() {
		this.students = new ArrayList<>();
	}

	public StudentManager(ArrayList<Student> students) {
		this.students = students;
	}

	public void add(Student s) {
		students.add(s);
	}

	public void add(ArrayList<Student> s) {
		students.addAll(s);
	}

	public void showStudents() {
		if (this.students.size() > 0) {
			System.out.println("Danh sách sinh viên");
			for (int i = 0; i < this.students.size(); i++)
				System.out.println(this.students.get(i));
		} else {
			System.out.println("Chưa có sinh viên nào");
		}

	}

	public void deleteStudent(Student s) {
		for (int i = 0; i < students.size(); i++) {
			Student st = students.get(i);
			if (st.equals(s)) {
				students.remove(i);
				break;
			}
		}
	}

	public void deleteStudent(String studentID) {
		for (int i = 0; i < students.size(); i++) {
			Student st = students.get(i);
			String id = st.getStudentID();
			if (id.equals(studentID)) {
				students.remove(i);
				break;
			}
		}
	}

	public void updateStudent(Student s) {
		for (int i = 0; i < students.size(); i++) {
			Student st = students.get(i);
			if (st.equals(s)) {
				students.set(i, s);
				break;
			}
		}
	}

	public void updateStudent(String studentID, Student s) {
		for (int i = 0; i < students.size(); i++) {
			Student st = students.get(i);
			String id = st.getStudentID();
			if (id.equals(studentID)) {
				students.set(i, s);
				break;
			}
		}
	}

	public Student searchStudent(String studentID) {
		for (Student student : this.students) {
			String id = student.getStudentID();
			if (id.equals(studentID))
				return student;
		}
		return null;
	}

	public Student searchStudent(Student s) {
		for (Student student : this.students) {
			if (student.equals(s))
				return student;
		}
		return null;
	}

	public void sortByScore() {
		Collections.sort(this.students, new Comparator<Student>() {

			@Override
			public int compare(Student o1, Student o2) {
				// TODO Auto-generated method stub
				return o1.calculateAverage() > o2.calculateAverage() ? 1 : -1;
			}
		});
	}

	public void sortByAge() {
		Collections.sort(this.students, new Comparator<Student>() {

			@Override
			public int compare(Student o1, Student o2) {
				// TODO Auto-generated method stub
				return o1.getAge() > o2.getAge() ? 1 : -1;
			}
		});
	}

	public void sortByID() {
		Collections.sort(this.students, new Comparator<Student>() {

			@Override
			public int compare(Student o1, Student o2) {
				// TODO Auto-generated method stub
				return o1.getStudentID().compareTo(o2.getStudentID());
			}
		});
	}

	public void sortByType() {
		Collections.sort(this.students, new Comparator<Student>() {

			@Override
			public int compare(Student o1, Student o2) {
				// TODO Auto-generated method stub
				if (o1 instanceof StudentBA && o2 instanceof StudentIT)
					return 1;
				return -1;
			}
		});
	}

	@Override
	public String toString() {
		String str = "";
		for (int i = 0; i < this.students.size(); i++) {
			str = str + "\t" + this.students.get(i);
			if (i != this.students.size())
				str = str + ",";
			str = str + "\n";
		}
		return "StudentManager [students=\n" + str + "]";
	}

	public ArrayList<Student> getStudents() {
		return students;
	}

	public void setStudents(ArrayList<Student> students) {
		this.students = students;
	}

}
