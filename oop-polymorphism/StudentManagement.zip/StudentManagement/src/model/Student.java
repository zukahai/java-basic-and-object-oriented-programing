package model;

import java.util.Scanner;

public class Student {
	private String studentID;
	private String name;
	private int age;

	public Student() {
		this.studentID = "";
		this.name = "";
		this.age = 0;
	}

	public Student(String studentID, String name, int age) {
		this.studentID = studentID;
		this.name = name;
		this.age = age;
	}

	public void input() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhập ID: ");
		this.studentID = sc.nextLine();
		System.out.print("Nhập Name: ");
		this.name = sc.nextLine();
		System.out.print("Nhập Age: ");
		this.age = sc.nextInt();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		Student otherStudent = (Student) obj;
		return this.getStudentID().equals(otherStudent.getStudentID());

	}
	
	public void incAge() {
		this.age++;
	}
	
	public void decAge() {
		this.age++;
	}
	
	public void incAge(int n) {
		this.age += n;
	}
	
	public void decAge(int n) {
		this.age += n;
	}
	
	public float calculateAverage() {
		return 0;
	}
	
	public Student copyObject() {
		return new Student(studentID, name, age);
	}

	@Override
	public String toString() {
		return "Student [studentID=" + studentID + ", name=" + name + ", age=" + age + "]";
	}

	public String getStudentID() {
		return studentID;
	}

	public void setStudentID(String studentID) {
		this.studentID = studentID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
}