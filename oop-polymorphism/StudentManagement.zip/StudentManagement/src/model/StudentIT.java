package model;

import java.util.Scanner;

public class StudentIT extends Student {
	private float scoreCPP;
	private float scoreJava;

	public StudentIT() {
		super();
		this.scoreCPP = 0;
		this.scoreJava = 0;
	}

	public StudentIT(String studentId, String name, int age, float scoreCPP, float scoreJava) {
		super(studentId, name, age);
		this.setScoreCPP(scoreCPP);
		this.setScoreJava(scoreJava);
	}

	@Override
	public String toString() {
		return "StudentIT [studentID=" + super.getStudentID() + ", name=" + super.getName() + ", age=" + super.getAge()
				+ ", scoreCPP=" + scoreCPP + ", scoreJava=" + scoreJava + "]";
	}

	public void input() {
		super.input();
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhập ScoreCPP: ");
		this.setScoreCPP(sc.nextFloat());
		System.out.print("Nhập ScoreJava: ");
		this.setScoreJava(sc.nextFloat());
	}

	public float calculateAverage() {
		return (scoreCPP + scoreJava) / 2;
	}
	
	public Student copyObject() {
		return new StudentIT(super.getStudentID(), super.getName(), super.getAge(), scoreCPP, scoreJava);
	}

	public float getScoreCPP() {
		return scoreCPP;
	}

	public void setScoreCPP(float scoreCPP) {
		this.scoreCPP = scoreCPP;
		if (scoreCPP < 0 || scoreCPP > 10)
			this.scoreCPP = 0;
	}

	public float getScoreJava() {
		return scoreJava;
	}

	public void setScoreJava(float scoreJava) {
		this.scoreJava = scoreJava;
		if (scoreJava < 0 || scoreJava > 10)
			this.scoreJava = 0;
	}

}
