package model;

import java.util.Scanner;

public class Menu {
	private StudentManager smanager;

	public Menu() {
		smanager = new StudentManager();
	}

	public int choiceMenu() {
		Scanner sc = new Scanner(System.in);
		System.out.println("\n+-------- Quản lí sinh viên -------+");
		System.out.println("| 1. Nhập thông tin sinh viên      |");
		System.out.println("| 2. Xem danh sách sinh viên       |");
		System.out.println("| 3. Tìm kiếm sinh viên            |");
		System.out.println("| 4. Xoá sinh viên                 |");
		System.out.println("| 5. Cập nhập thông tin sinh viên  |");
		System.out.println("| 6. Sắp xếp sinh viên             |");
		System.out.println("| 7. Thoát                         |");
		System.out.println("+----------------------------------+");
		System.out.print("Nhập lựa chọn của bạn: ");
		return sc.nextInt();
	}
	
	public int choiceMenu(int c) {
		Scanner sc = new Scanner(System.in);
		switch (c) {
			case 1:
				System.out.println("\n+----------- Nhập thông tin  ---------+");
				System.out.println("| 1. Nhập thông tin sinh viên IT      |");
				System.out.println("| 2. Nhập thông tin sinh viên BA      |");
				System.out.println("+-------------------------------------+");
				break;
			case 6:
				System.out.println("\n+--------- Sắp xếp  --------+");
				System.out.println("| 1. Theo điểm trung bình   |");
				System.out.println("| 2. Theo tuổi              |");
				System.out.println("| 3. Theo ID                |");
				System.out.println("| 4. Theo ngành học         |");
				System.out.println("+---------------------------+");
				break;
	
		}
		
		System.out.print("Nhập lựa chọn của bạn: ");
		return sc.nextInt();
	}
	
	public void input(int c) {
		Student t;
		switch (c) {
			case 1: 
				t = new StudentIT();
				break;
			case 2:
				t = new StudentBA();
				break;
			default:
				System.out.println("Lựa chọn không đúng");
				return;
		}
		t.input();
		Student tmp = smanager.searchStudent(t);
		if (tmp != null)
			System.out.println("Thêm sinh viên thất bại. Mã sinh viên đã tồn tại");
		else  {
			smanager.add(t);
			System.out.println("Thêm sinh viên thành công");
		}
	}
	
	public void showStudents() {
		smanager.showStudents();
	}
	
	public void search() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhập ID sinh viên cần tìm kiếm: ");
		String studentID = sc.nextLine();
		Student t = smanager.searchStudent(studentID);
		if (t == null)
			System.out.println("Không tồn tại sinh viên ID là: " + studentID);
		else {
			System.out.println("Tìm kiếm hoàn tất sinh viên có ID là: " + studentID);
			System.out.println(t);
		}
	}
	
	public void deleteSutdent() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhập ID sinh viên cần xoá: ");
		String studentID = sc.nextLine();
		Student t = smanager.searchStudent(studentID);
		if (t == null)
			System.out.println("Không tồn tại sinh viên ID là: " + studentID);
		else {
			System.out.println("Xoá hoàn tất sinh viên có ID là: " + studentID);
			smanager.deleteStudent(studentID);
		}
	}
	
	public void updateStudent() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhập ID sinh viên cần cập nhật: ");
		String studentID = sc.nextLine();
		Student t = smanager.searchStudent(studentID);
		if (t == null)
			System.out.println("Không tồn tại sinh viên ID là: " + studentID);
		else {
			System.out.println("Nhập thông tin mới");
			Student newStudent = t.copyObject();
			newStudent.input();
			Student t2 = smanager.searchStudent(newStudent.getStudentID());
			if (t2 != null && !t2.getStudentID().equals(studentID)) {
				System.out.println("ID của thông tin mới đã tồn tại");
			} else {
				smanager.updateStudent(studentID, newStudent);
				System.out.println("Cập nhật thành công!");
			}
			
		}
	}
	
	public void sortStudent(int c) {
		switch (c) {
			case 1:
				smanager.sortByScore();
				break;
			case 2:
				smanager.sortByAge();
				break;
			case 3:
				smanager.sortByID();
				break;
			case 4:
				smanager.sortByType();
				break;
			default:
				System.out.println("Lựa chọn không đúng");
				return;
		}
		System.out.println("Đã sắp xếp thành công!");
		
	}
	
	public void run() {
		int choice, choice2;
		String studentID;
		do {
			choice = choiceMenu();
			switch (choice) {
				case 1:
					choice2 = choiceMenu(1);
					input(choice2);
					break;
				case 2:
					showStudents();
					break;
				case 3:
					search();
					break;
				case 4:
					deleteSutdent();
					break;
				case 5:
					updateStudent();
					break;
				case 6:
					choice2 = choiceMenu(6);
					sortStudent(choice2);
					break;
				case 7:
					break;
				default:
					System.out.println("Lựa chọn không đúng");
					return;
				
			}
		} while(choice != 7);
		System.out.println("Kết thúc chương trình!");
	}
}
