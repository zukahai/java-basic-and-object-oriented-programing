package model;

import java.util.Scanner;

public class StudentBA extends Student {
	private float scorePM;
	private float scoreBA;

	public StudentBA() {
		super();
		this.scorePM = 0;
		this.scoreBA = 0;
	}

	public StudentBA(String studentId, String name, int age, float scorePM, float scoreBA) {
		super(studentId, name, age);
		this.setScorePM(scorePM);
		this.setScoreBA(scoreBA);
	}

	@Override
	public String toString() {
		return "StudentBA [studentID=" + super.getStudentID() + ", name=" + super.getName() + ", age=" + super.getAge()
				+ ", scorePM=" + scorePM + ", scoreBA=" + scoreBA + "]";
	}

	public void input() {
		super.input();
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhập ScorePM: ");
		this.setScorePM(sc.nextFloat());
		System.out.print("Nhập ScoreBA: ");
		this.setScoreBA(sc.nextFloat());
	}

	public float calculateAverage() {
		return (scorePM + scoreBA) / 2;
	}
	
	public Student copyObject() {
		return new StudentBA(super.getStudentID(), super.getName(), super.getAge(), scorePM, scoreBA);
	}

	public float getScorePM() {
		return scorePM;
	}

	public void setScorePM(float scorePM) {
		this.scorePM = scorePM;
		if (scorePM < 0 || scorePM > 10)
			this.scorePM = 0;
	}

	public float getScoreBA() {
		return scoreBA;
	}

	public void setScoreBA(float scoreBA) {
		this.scoreBA = scoreBA;
		if (scoreBA < 0 || scoreBA > 10)
			this.scoreBA = 0;
	}

}
